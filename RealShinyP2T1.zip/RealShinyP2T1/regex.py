import json
import re
import pandas as pd
import spacy
import sqlalchemy as sql

# Load SpaCy model
nlp = spacy.load("en_core_web_sm")

# SQLAlchemy engine
engine = sql.create_engine('postgresql://neondb_owner:KDaTfyRS8Gs4@ep-dawn-cell-a5ks0rn2-pooler.us-east-2.aws.neon.tech:5432/neondb?sslmode=require&options=endpoint%3Dep-dawn-cell-a5ks0rn2-pooler')

def load_processed_articles(file_path):
    with open(file_path, 'r') as f:
        return json.load(f)

patterns = {
    #'ref_number_pattern': r"\b[A-Za-z0-9]+\b",
    'updated_date': r"\b(0[1-9]|1[0-2])/(0[1-9]|[12][0-9]|3[01])/(19|20)\d\d\b",
    'company_names': r"[A-Za-z0-9\s.,'-]+\b",
    'partners': r"[A-Za-z0-9\s.,'-]+(?:, [A-Za-z0-9\s.,'-]+)*\b",
    #'comments': r".*",
    #'location': r"[A-Za-z0-9\s.,'-]+\b",
    'process': r"\b(not indicated|alcohol-to-jet|fermentation|catalytic hydrothermolysis|SHJ|Gasification /FT|FT|Hydroprocessing|UOP Ecofining|HEFA|Power-to-Liquid|PTL|ATJ|hydroflex|pyrolysis|TOPSOE)\b",
    'atsm': r"\bASTM\s[A-Z]\d{3}-\d{2}\b",
    'pathway': r"\b(ATJ|CH|FT|HEFA|PtL)\b",
    'entry_date': r"\b(0[1-9]|1[0-2])/(0[1-9]|[12][0-9]|3[01])/(19|20)\d\d\b",
    'in_service': r"\b(Yes|No)\b",
    'earliest_date': r"\b(0[1-9]|1[0-2])/(0[1-9]|[12][0-9]|3[01])/(19|20)\d\d\b",
    'ground_breaking_date': r"\b(0[1-9]|1[0-2])/(0[1-9]|[12][0-9]|3[01])/(19|20)\d\d\b",
    'first_start_date': r"\b(0[1-9]|1[0-2])/(0[1-9]|[12][0-9]|3[01])/(19|20)\d\d\b",
    'start_current_projected_start_year': r"\b(19|20)\d\d\b",
    #'notes': r".*",
    'original_cost': r"\b\d+(\.\d{1,2})?\s?(million|billion|dollars)?\s?\$\b",
    'updated_cost': r"\b\d+(\.\d{1,2})?\s?(million|billion|dollars)?\s?\$\b",
    'build_type': r"\b(greenfield|co-location|conversion)\b",
    'original_announcement_MGY_pattern' : r"\b\d+(\.\d{1,2})?\s?(MGY|gallon|gallons)\b",
    'announced_saf_vol_MGY_pattern' : r"\b\d+(\.\d{1,2})?\s?(MGY|gallon|gallons)\b",
    'facility_type': r"\b(commercial|demo|pilot)\b",
    'fuel': r"\b(diesel|fet fuel|iso-octane|isobutanol|ethanol|SAF|RD|renewable diesel and jet|ReadiJet|ReadiDiesel napths|gasoline|LPG|propane|eFuels|eMethanol|Chemicals)\b",
    'feedstock': r"\b(vegetable oils and animal fats|soybean oil and other renewable feedstocks|oilcrops|oils|fats|lignocellulose and other biomass|MSW|sugar beets|sugarcane|corn starch|bagasse|corn stover|grasses|wood|DAC|lipids|DGCO|solar|wastes|sugar ethanol|corn ethanol|timber|ag waste|CO2|forest and ag residues|inedible corn|renewable electricity|RNG|natural gas|captured flare|fugitive gas|cellulosics|camellia|low carbon ethanol|wood waste|bio-solids|industrial waste|sewage|medical waste|hydro power|UCO|tallow|cooking oil|brush|woody biomass|greases)\b",
    'updated_info': r"\b(update|updated)\b",
   # 'references': r".*",
   # 'timeline_ref': r".*",
   # 'cost_ref': r".*"
   'other_terms':r"\b(Sustainable fuel|Carbon Offsetting and Reduction Scheme for International Aviation|sustainable aviation fuel|SAF|alternative jet fuel|AJF|CORSIA|Alternative Jet Fuel|Renewable Fuel|Aviation Alternative Fuels|biofuel|renewable fuel|alternative fuel|Sustainable aviation|Low-carbon aviation fuels|Green aviation|Bio-based aviation fuels|Renewable jet fuels|Aviation decarbonization|Carbon-neutral aviation|Jet fuel alternatives|Aviation sustainability initiatives|Carbon offsetting in aviation|Aviation emissions reduction|Sustainable energy for aviation|Greenhouse gas reduction in aviation|Aviation fuel innovation|Aviation bioenergy|Carbon-conscious aviation|Clean aviation fuels|Eco-friendly aviation fuels|Aviation fuel technology|Sustainable air travel initiatives)\b",
    'fuel_terms_SAF_for_RD':r"\b(aviation biofuel|biojet|Sustainable Aviation Biofuel|Bio-Aviation Fuel|Bioaviation Fuel|Biojet Fuel|Bio-Jet Fuel|Sustainable Aviation Fuel|alternative jet fuel|AJF|renewable jet fuel|Diesel|renewable diesel|Honeywell Green Diesel™|Honeywell Green Jet Fuel ™|RD|HVO|SAF|hydrotreated vegetable oils)\b",
    'alcohol_to_jet':r"\b(alcohol|methanol to jet|methanol to SAF|MTJet|alcohol to jet|alcohol-to-jet|alcohol-to-jet synthetic paraffinic kerosene|ATJ-SPK|ethanol to jet|ethanol-to-jet|ATJ|Alcohol to Jet Synthetic Paraffinic Kerosene|ATJ Synthetic Paraffinic Kerosene|Alcohol-to-Sustainable Aviation Fuel|Alcohol to Sustainable Aviation Fuel|M-SAF|Methanol-to-Jet|M-to-SAF|M to SAF|M to Jet|M-to-Jet|Methanol-to-Aviation-Fuel|Methanol to Aviation Fuel|Methanol-to-SAF|ETJ|Hydroprocessed Fermented Sugars|HFS|Hydroprocessed Fermented Sugars to Synthetic Isoparaffins|HFS-SIP|HFS-SPK|HFS-Jet Fuel|HFS Jet Fuel)\b",
    'HEFA_synonyms':r"\b(hydro-processed esters and fatty acids|hydroprocessed esters and fatty acids|HEFA|HEFA-SPK|Hydroprocessed Fatty Acid Esters and Fatty Acids|Hydroprocessed Fatty Acid Esters)\b",
    'GFT_synonyms':r"\b(Fischer|Fischer-Tropsch Synthetic Paraffinic Kerosene|FT-SPK|gasification Fischer-Tropsch|gasification Fischer-Tröpsch|FT|Fischer-Tropsch|Fischer-Tröpsch|Fischer-Tropsch Synthesis|Fischer-Tropsch Process|Fischer-Tropsch Synthesized Isoparaffinic Kerosene|Fischer-Tropsch Jet Fuel|GFT)\b",
    'other_process_technologies':r"\b(catalytic hydrothermolysis|pyrolysis|co-processing|hydroflex|SIP|CH|Catalytic Hydrothermolysis for Jet Fuel|Catalytic HT|CH-Jet Fuel|ecofining|UOP Ecofining|BioFlux|Topsoe|Honeywell UOP)\b",
    'PtL_synonyms':r"\b(e-fuels|e-SAF|eSAF|power to liquid|power-to-liquid|Electrofuels|E-jet Fuel|Efuel|high electricity input fuels)\b",
    'Volume':r"\b(tons per year|gallons per year|liters per year|MJ per year|megajoules per year|barrels per day|barrels per year|kg/hour|kg/h|tpy|kt/y|MGY|cubic meters per year|m3/y|MLY|MW|million gallons per year)\b",
    'Dates':r"\b(announced start year|actual start year|article date|inauguration|completion|start producing|finished building|FID|final investment decision|start up|start-up)\b",
    'Failure':r"\b(bankruptcy|cancellation|closed|stopped|shuttered|postponed|shelved)\b",
    'Finance_details':r"\b(offtake|government support|government grant|municipal bonds|green bonds|tax credit|incentives|subsidies|mandates|funding|loan|equity|grant|bankable|take or pay)\b",
    'Feedstock':r"\b(forest residue|woody biomass|agricultural residue|agricultural waste|agricultural residuals|sugar|corn grain|corn|corn stover|corn starch|lipids|triglycerides|soybean oil|rapeseed oil|palm oil|crude palm oil|waste fats|fats, oils and greases|FOGs|used cooking oil|UCO|used vegetable oil|UVO|tallow|lard|animal fat|Brassica carinata|carinata|pennycress|camelina|canola oil|isobutanol|cellulosic ethanol|macauba|vegetable oil|municipal solid waste|MSW|organic residues|brown grease|energy cane|sugarcane|miscanthus|switchgrass|poplar|eucalyptus|palm oil residues|fatty acids|forest residuals|renewable methanol|biomethanol|green methanol|Renewable Methyl Alcohol|RM|Sustainable Methanol|second crop oilseeds|energy crops|short rotation woody crops|short rotation woody biomass|algae)\b",
    'Production_Location':r"\b(country|location|city)\b",
    'Announced_Fuels': r"\b(SAF|RD|renewable diesel|green diesel|ethanol|gasoline|naphtha|propane|methanol|renewable LPG|isooctane|RNG|renewable natural gas)\b",
    'Business':r"\b(financing|partners|expansion|conversion of petroleum refinery|demo|pilot|commercial|under construction|fuel readiness level|FRL|ASTM approval|investment of|inversion|direct jobs|indirect jobs)\b",
    'Misc':r"\b(Hydrothermal liquefaction|HTL|Cyclobutane from prehydrolysis liquors|Low-cetane|Cupriavidus necator on formic acid|Hydrodeoxygenation of Lignin-Derived Model Compound|Jet-stirred reactor|RQL Sector Cumbustor|Lignocellulosic Feedstock|Microalgal biodiesel|Microalgae)\b"

}

def extract_locations(text):
    "Extracts locations using spaCy named entity recognition."
    locations = []
    doc = nlp(text)
    for ent in doc.ents:
        if ent.label_ == "GPE":
            locations.append(ent.text)
    return locations

def extract_information(article):
    "Extracts relevant information from a processed article."
    extracted_info = {}
    
    for key, pattern in patterns.items():
        match = re.search(pattern, article["text"])
        if match:
            extracted_info[key] = match.group()
            print(f"found {key}: {match.group()}")
            
    locations = extract_locations(article["text"])
    if locations:
        extracted_info["locations"] = locations
        
    extracted_info["url"] = article["url"]
    doc = nlp(article["text"])
    extracted_info["company_names"] = [ent.text for ent in doc.ents if ent.label_ == "ORG"]
    extracted_info["partners"] = [ent.text for ent in doc.ents if ent.label_ == "PERSON"]
    return extracted_info

def insert_data_into_database(data):
    "Inserts extracted data into PostgreSQL database."
    df = pd.DataFrame(data)
    df.to_sql('extracted_data', engine, if_exists='append', index=False)

def main():
    extracted_data = []
    
    for article in processed_articles:
        extracted_info = extract_information(article)
        extracted_data.append(extracted_info)
        
    # Convert extracted data to DataFrame
    df = pd.DataFrame(extracted_data)
    
    # Save extracted data as JSON
    with open('extracted_data.json', 'w') as f:
        json.dump(extracted_data, f)
        
    # Save extracted data as CSV
    df.to_csv('extracted_data.csv', index=False)
    
    # Load the extracted data DataFrame
    extracted_data_df = pd.read_csv('extracted_data.csv')
    
    # Insert the extracted data into the database
    insert_data_into_database(extracted_data_df)

if __name__ == "__main__":
    processed_articles = load_processed_articles('processed_articles.json')
    main()

