# Load required libraries
library(shiny)
library(shinythemes)
library(ggplot2)
library(dplyr)
library(readxl)

# Our data -- currently what is extracted from Regex from Kristin's URLs to a csv -- done outside of Shiny.
# !!! <connect to run regex.py using reticulate>
data <- read.csv("extracted_data.csv")
columnnames = sort(colnames(data))


# Kristin's given data to use for graphics: 

# a) Graphics data
graphics_data <- read_excel("US SAF Producers_KristinsData.xlsx")
colnames(graphics_data) = make.names(names(graphics_data))
print(names(graphics_data))
# b) Derived success ratio data
# Could eventually write something to derive success ratio data from Regex data. 
# Could also just deactivate this part when Regex is successful/original dataset is obsolete.
success_data <- read_excel("success_ratio_by_tech.xlsx")


# Mapping from what Regex produces for colnames to Kristin's given data colnames as used in graphics, so can eventually
# invoke to read data from Regex to the functions for the graphics.
# Mapping must also create column for calculations/mutations used in graphics,
# including for "Most Recent Cost billion"
# !!! <insert mapping>


# Define UI
ui <- fluidPage(
  theme = shinytheme("cerulean"),
  navbarPage(
    title = "ASCENT Webscraper: Sustainable Aviation Fuel Production Analysis",
    tabPanel("Project Overview", 
             fluidRow(
               column(12, 
                      tags$div(
                        style = "margin-top: 20px;",
                        tags$h2("Project Overview"),
                        tags$p("This project aims to address the hurdle of dynamic and continually updating public announcements of renewable hydrocarbon production. We are developing a database system to collect, store, validate, and update announcements of renewable hydrocarbon production projects. The primary goal is to automate data collection to ensure accuracy, completeness, and reduce manual workload. The data collected will be utilized for summary statistics, visualizations, and to track industry growth for the ASCENT project, particularly for the Sustainable Aviation Fuel (SAF) Grand Challenge."),
                        tags$p("Methodology and code can be found at https://gitlab.eecs.wsu.edu/data_424_2024/team_3/-/tree/main?ref_type=heads."),
                        tags$p("Please use the tabs to navigate between data visualizations, or use the below widget to download extracted production data."),
                        tags$hr(),
                        tags$h4("Data Dictionary"),
                        tableOutput("data_dictionary"),
                        tags$hr(),
                        tags$h4("Export SAF Production Data"),
                        tags$hr(),
                        actionLink("selectall","Select All"),
                        tags$hr(),
                        actionLink("unselectall","Unselect All"),
                        tags$hr(),
                        checkboxGroupInput("columns_to_export", "Select Columns to Export:",
                                           choices = columnnames),
                        downloadButton("export_button", "Export Selected Columns"),
                        tags$hr()
                      )
                        
               )
             )
    ),
    
    tabPanel("Success Ratio by Technology",   
      sidebarLayout(
        sidebarPanel(
          selectInput("Technology", "Select Technology", choices = unique(success_data$Technology)),
          hr(),
          helpText("Choose a technology from the dropdown menu to see its histogram.")
        ),
        mainPanel(
          plotOutput("success_histogram")
        )
      )
    ),
    # Total Costs by Technology -- did Kristin mean average costs/volume instead?
    tabPanel("Cost by Technology",
             fluidRow(
               column(12,
                      plotOutput("cost_by_technology")

               )
             )
    ),
    tabPanel("Project Timeline", 
             fluidRow(
               column(12, 
                      plotOutput("project_timeline")
               )
             )
    ),
    tabPanel("Volume by Technology", 
             fluidRow(
               column(12, 
                      plotOutput("volume_by_technology")
               )
             )
    )
  )
)

# Define server logic
server <- function(input, output, session) {

  
  # Data Dictionary
  dictionary = read_excel("shiny_Data_Dictionary.xlsx")
  
  output$data_dictionary <- renderTable({
    dictionary
  })
  
  
  #Select or unselect all for download data option
  
  #Select all
  observe({
    if(input$selectall == 0) return(NULL) 
    else if (input$selectall%%2 == 0)
    {
      updateCheckboxGroupInput(session,"columns_to_export", "Select Columns to Export:", choices = columnnames)
    }
    else
    {
      updateCheckboxGroupInput(session,"columns_to_export", "Select Columns to Export:", choices = columnnames, selected = columnnames)
    }
  })
  
  #Unselect all
  observe({
    if(input$unselectall == 0) return(NULL) 
    else if (input$unselectall%%2 == 0)
    {
      updateCheckboxGroupInput(session,"columns_to_export", "Select Columns to Export:", choices = columnnames, selected = columnnames)
    }
    else
    {
      updateCheckboxGroupInput(session,"columns_to_export", "Select Columns to Export:", choices = columnnames)
    }
  })
  
      # Trigger the download
      output$export_button <-  downloadHandler(
        filename = function() {
          "SAF_production_data.csv"
        },
        content = function(file) {
          selected_columns <- input$columns_to_export
          if (length(selected_columns) > 0) {
            exported_data <- data[, selected_columns, drop = FALSE]
          
          write.csv(exported_data, file)
        }
        }
      )

      
  # Success histograms
      #Consider making one of success rates between technologies
      output$success_histogram <- renderPlot({
        
        success_data <- success_data[success_data$Technology == input$Technology, ]
        
        # Extract column names and values (excluding the first column)
        col_names <- names(success_data)[-1]
        values <- as.numeric(success_data[1, -1])
        
        # Create a data frame for plotting
        plot_data <- data.frame(
          Technology = col_names,
          Value = values
        )
        
        # Plot using ggplot
        ggplot(plot_data, aes(x = Technology, y = Value)) +
          geom_bar(stat = "identity", fill = "blue") +
          labs(title = "Bar plot of Excel data",
               x = "Technology",
               y = "Value") +
          theme_minimal() +
          theme(axis.text.x = element_text(angle = 45, hjust = 1)) +
          geom_text(aes(label = Value), vjust = -0.3)
        
      })


  
  # Cost by Technology plot
  output$cost_by_technology <- renderPlot({
    ggplot(graphics_data, aes(x =Pathway , y = Most.Recent.Cost.billion)) +
      geom_bar(stat = "identity", fill = "skyblue") +
      labs(title = "Total Costs by Technology", x = "Technology", y = "Cost (billions)")
  })

  
  # Project Timeline plot
  output$project_timeline <- renderPlot({
    ggplot(graphics_data, aes(x = Earliest.Date.Found, y = Time.from.first.announcement.to.production, color = Pathway)) +
      geom_point() +
      geom_smooth(method = "lm") +
      labs(title = "Project Timeline", x = "Announcement Date", y = "Years to Enter Service")
  })
  

  # Volume by Technology plot
  output$volume_by_technology <- renderPlot({
    ggplot(graphics_data, aes(x = Pathway, y = Original.announcement.MGY)) +
      geom_bar(stat = "identity", fill = "lightblue") +
      labs(title = "Volume by Technology", x = "Technology", y = "Volume (millions of gallons per year)")
  })
}

# Run the application
shinyApp(ui = ui, server = server)
